print("Hello, World")
a = 10
b = 15
c="The total is"
print(c)
print(a/b)
4/2